﻿using Refuerzo2024.Model.DAO;
using Refuerzo2024.View.Docentes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Refuerzo2024.Controller.Docentes
{
    internal class ControllerDocente
    {
        ViewDocentes objDocente;

        public ControllerDocente(ViewDocentes objDocente)
        {
            this.objDocente = objDocente;

            // Aquí es donde le decimos al sistema qué hacer cuando el usuario hace algo
            objDocente.Load += new EventHandler(CargaInicial);
            objDocente.btnAgregarDocente.Click += new EventHandler(RegistrarDocente);
            objDocente.dgvDocente.CellClick += new DataGridViewCellEventHandler(SeleccionarDato);
            objDocente.btnActualizar.Click += new EventHandler(ActualizarDocente);
            objDocente.btnEliminar.Click += new EventHandler(EliminarDocente);
            objDocente.btnBuscar.Click += new EventHandler(BuscarDocente);
        }

        public void CargaInicial(object sender, EventArgs e)
        {
            // Al cargar la vista, llenamos el DataGridView con los datos
            LlenarDataGridViewDocente();
        }

        public void SeleccionarDato(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica si realmente seleccionamos una fila
            if (objDocente.dgvDocente.CurrentRow != null)
            {
                // Aquí agarramos la fila en la que hicimos clic
                int pos = objDocente.dgvDocente.CurrentRow.Index;

                // Comprobamos que haya al menos 4 columnas (porque tenemos 4 en total)
                if (objDocente.dgvDocente.ColumnCount >= 4)
                {
                    // Aquí llenamos los campos con los datos de la fila
                    objDocente.txtIDDocente.Text = objDocente.dgvDocente[0, pos].Value.ToString();   // Columna 0
                    objDocente.txtNombresDocente.Text = objDocente.dgvDocente[1, pos].Value.ToString(); // Columna 1
                    objDocente.txtApellidosDocente.Text = objDocente.dgvDocente[2, pos].Value.ToString(); // Columna 2
                    objDocente.txtDocumentoDocente.Text = objDocente.dgvDocente[3, pos].Value.ToString(); // Columna 3
                }
                else
                {
                    // Si hay menos de 4 columnas, algo raro pasa
                    MessageBox.Show("El DataGridView no tiene suficientes columnas para acceder a la información.",
                                    "Error de columna", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Si no seleccionamos ninguna fila, pues avísamos
                MessageBox.Show("No se ha seleccionado ninguna fila. Por favor, selecciona un docente.",
                                "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void RegistrarDocente(object sender, EventArgs e)
        {
            DAODocente data = new DAODocente();
            data.NombreDocente = objDocente.txtNombresDocente.Text.Trim();
            data.ApellidoDocente = objDocente.txtApellidosDocente.Text.Trim();
            data.Dui = objDocente.txtDocumentoDocente.Text.Trim();
            // Aquí intentamos guardar los datos y vemos si todo salió bien
            if (data.RegistrarDocente() == true)
            {
                MessageBox.Show("Datos registrados correctamente", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se pudo guardar los datos", "Proceso incompleto", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LlenarDataGridViewDocente()
        {
            DAODocente obj = new DAODocente();
            DataSet ds = obj.ObtenerDocente();
            // Llenamos el DataGridView con los datos de los docentes
            objDocente.dgvDocente.DataSource = ds.Tables["Docentes"];
        }

        public void ActualizarDocente(object sender, EventArgs e)
        {
            DAODocente data = new DAODocente();
            data.IdDocente = int.Parse(objDocente.txtIDDocente.Text.Trim().ToString());
            data.NombreDocente = objDocente.txtNombresDocente.Text.Trim();
            data.ApellidoDocente = objDocente.txtApellidosDocente.Text.Trim();
            data.Dui = objDocente.txtDocumentoDocente.Text.Trim();
            // Actualizamos los datos y se verifica  ssi todo salió bien
            if (data.ActualizarDocente() == true)
            {
                MessageBox.Show("Los datos fueron actualizados correctamente", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LlenarDataGridViewDocente();
            }
            else
            {
                MessageBox.Show("Los datos no pudieron ser actualizados.", "Proceso interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void EliminarDocente(object sender, EventArgs e)
        {
            // Si no seleccionamos ningún docente se muestra un mensaje
            if (string.IsNullOrEmpty(objDocente.txtIDDocente.Text.Trim()))
            {
                MessageBox.Show("Seleccione un registro", "Seleccione un valor", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DAODocente data = new DAODocente();
                data.IdDocente = int.Parse(objDocente.txtIDDocente.Text);
                // Confirmamos si realmente se va borrar el docente
                if (MessageBox.Show("¿Desea eliminar el registro seleccionado?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Si todo va bien se elimina al profe
                    if (data.EliminarDocente() == true)
                    {
                        MessageBox.Show("El dato fue eliminado correctamente", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LlenarDataGridViewDocente();
                    }
                    else
                    {
                        MessageBox.Show("El registro no pudo ser eliminado", "Proceso interrumpido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public void BuscarDocente(object sender, EventArgs e)
        {
            DAODocente data = new DAODocente();
            DataSet ds = data.BuscarDocente(objDocente.txtBuscar.Text.Trim());
            // Aquí buscamos al docente y los resultados en el DataGridVie
            objDocente.dgvDocente.DataSource = ds.Tables["Docentes"];
        }
    }
}
