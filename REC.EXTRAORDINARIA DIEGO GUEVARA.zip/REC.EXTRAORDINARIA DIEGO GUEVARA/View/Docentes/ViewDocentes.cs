﻿using Refuerzo2024.Controller.Docentes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Refuerzo2024.View.Docentes
{
    public partial class ViewDocentes : Form
    {
        public ViewDocentes()
        {
            InitializeComponent();

            // Cambiar el color de fondo de las celdas
            dgvDocente.DefaultCellStyle.BackColor = Color.LightBlue;
            dgvDocente.DefaultCellStyle.ForeColor = Color.Black;

            // Cambiar el color de las filas alternas
            dgvDocente.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

            // Cambiar el color de las filas seleccionadas
            dgvDocente.DefaultCellStyle.SelectionBackColor = Color.DarkBlue;
            dgvDocente.DefaultCellStyle.SelectionForeColor = Color.White;

            // Inicializar el controlador (antes estaba en el otro constructor)
            ControllerDocente next = new ControllerDocente(this);
        }



        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
