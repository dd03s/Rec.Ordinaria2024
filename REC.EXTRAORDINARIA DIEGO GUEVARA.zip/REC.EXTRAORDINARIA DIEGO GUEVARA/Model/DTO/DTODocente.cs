﻿using Refuerzo2024.Model.Conexion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Refuerzo2024.Model.DTO
{
    // Esta clase es como una representación de un docente algo así como un modelo para los datos
    internal class DTODocente : dbContext
    {
        // Aqui estan los atributos que describen a un docente
        private int idDocente;
        private string nombreDocente;
        private string apellidoDocente;
        private string dui;

        // Estas son las propiedades que nos permiten acceder o modificar los valores de los atributos
        public int IdDocente { get => idDocente; set => idDocente = value; }
        public string NombreDocente { get => nombreDocente; set => nombreDocente = value; }
        public string ApellidoDocente { get => apellidoDocente; set => apellidoDocente = value; }
        public string Dui { get => dui; set => dui = value; }
    }
}

